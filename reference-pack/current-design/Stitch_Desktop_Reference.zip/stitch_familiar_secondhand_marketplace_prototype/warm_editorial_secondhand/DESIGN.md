---
name: Warm Editorial Secondhand
colors:
  surface: '#fef8f3'
  surface-dim: '#ded9d4'
  surface-bright: '#fef8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f8f3ee'
  surface-container: '#f3ede8'
  surface-container-high: '#ede7e2'
  surface-container-highest: '#e7e1dd'
  on-surface: '#1d1b19'
  on-surface-variant: '#494740'
  inverse-surface: '#32302d'
  inverse-on-surface: '#f5f0eb'
  outline: '#7a776f'
  outline-variant: '#cbc6bd'
  surface-tint: '#605e5b'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b19'
  on-primary-container: '#868380'
  inverse-primary: '#cac6c2'
  secondary: '#664db1'
  on-secondary: '#ffffff'
  secondary-container: '#af95ff'
  on-secondary-container: '#42268b'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002113'
  on-tertiary-container: '#44926f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e6e2de'
  primary-fixed-dim: '#cac6c2'
  on-primary-fixed: '#1c1b19'
  on-primary-fixed-variant: '#484644'
  secondary-fixed: '#e8ddff'
  secondary-fixed-dim: '#cebdff'
  on-secondary-fixed: '#21005e'
  on-secondary-fixed-variant: '#4e3397'
  tertiary-fixed: '#a4f3ca'
  tertiary-fixed-dim: '#88d7af'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#fef8f3'
  on-background: '#1d1b19'
  surface-variant: '#e7e1dd'
typography:
  display-hero:
    fontFamily: Newsreader
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Newsreader
    fontSize: 30px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 17px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  meta-measurement:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system serves an intentional secondhand garment marketplace anchored on evidence, physical fit confidence, and transparency. The brand rejects high-pressure e-commerce tactics—such as artificial urgency timers, aggressive drop counters, and saturated alert badges—in favor of quiet connoisseurship, thoughtful consideration, and tangible garment details.

The visual style blends **Editorial Warmth** with **Functional Tactility**:
- Uncoated paper feel: Canvas layers evoke heavy natural paper stock, tactile tags, and textile swatches.
- High editorial legibility paired with quiet, structural hierarchy.
- The interface acts as a neutral, respectful backdrop for high-resolution photography of weaves, seam stitching, care tags, and authentic wear patterns.
- Interaction cues favor deliberate inspection: measurement match comparisons, fabric composition breakdowns, and condition transparency.

## Colors

The palette is rooted in warm earthen foundations with a restrained system of pastel accents dedicated to classification, garment attributes, and state indicators rather than loud marketing promotions.

### Base & Text
- **Canvas Base**: `#FAF8F5` (Warm off-white base surface)
- **Surface Layer 1**: `#F5F2EC` (Cards, recessed containers, secondary surfaces)
- **Surface Layer 2**: `#ECE7DF` (Hover states, segmented controls, tertiary backing)
- **Ink Primary**: `#191816` (Deep carbon ink for primary headlines, active states, key data)
- **Ink Secondary**: `#2D2B28` (Grounded body text)
- **Ink Muted**: `#6E6A63` (Metadata, garment provenance, photo timestamps)
- **Quiet Border**: `#E7E3DB` (Subtle boundary lines, structural dividers)

### Category & Attribute Tints
- **Lilac Tone**: Base `#E6DEFA`, Solid `#876ED4` (Used for "Match" scoring, garment tailoring notes)
- **Powder Blue**: Base `#DDEAF8`, Solid `#557EAC` (Used for fabric blend stats, verified fiber content)
- **Mint Tone**: Base `#DCF2E7`, Solid `#3D8B68` (Used for verified authentic condition, repair logs)
- **Soft Pink**: Base `#FCE5EC`, Solid `#B85978` (Used for honest wear notations, flaws disclosure, and saved lists)

Never use stark pure black (`#000000`) or cold pure white (`#FFFFFF`) for large surfaces or text.

## Typography

Typography balances warm literary craft with structured analytical utility:
- **Newsreader** delivers an editorial tone reserved strictly for top-level section introductions, narrative garment backstories, and curated editorial collections. Set in regular weights with natural proportions.
- **Plus Jakarta Sans** provides clarity across functional interfaces, sizing matrices, filtration controls, and technical descriptions. Its geometric softness harmonizes with the rounded surfaces.
- Small labels and measurement numbers prioritize tabular clarity. Use uppercase sparingly, confined only to micro status tags (`label-sm`) with subtle letter-spacing.

## Layout & Spacing

The layout is built around mobile-first utility (baseline viewport: 390px) while maintaining proportion when expanded across tablet and desktop.

### Mobile Grid (Default, 390px)
- Margin: `1rem` (16px) left/right canvas padding.
- Gutter: `1rem` (16px) column gutter.
- Garment browsing grids operate in 2-column configurations on mobile devices with tight vertical gaps (`space-md`) to optimize continuous, steady inspection.
- Filter drawers and detail sheets pin to the bottom edge with standard safe-area padding.

### Desktop Scaling (>=1024px)
- Max content container: `1180px` centered.
- Outer Margins: `2.5rem` (40px).
- Gutter: `1.5rem` (24px) across an 8-column or 12-column system.
- Item detail view splits into a dual-column layout: Sticky multi-angle photographic evidence panel on the left (60% width), measurement validation and interaction panel on the right (40% width).

## Elevation & Depth

Visual hierarchy is achieved through **Tonal Layering** and **Quiet Outlines** rather than dramatic drop shadows.

- **Level 0 (Canvas)**: Background `#FAF8F5`. Flat, unbordered.
- **Level 1 (Cards & Modules)**: Background `#F5F2EC` bounded by a 1px solid `#E7E3DB` outline. No box-shadow is applied in resting state.
- **Level 2 (Active Sheets / Hovered Garments)**: Background `#FAF8F5`, 1px solid `#D8D3C8`, supported by an ambient shadow: `0 8px 24px -4px rgba(25, 24, 22, 0.06)`. The tint is derived directly from the deep ink base to avoid synthetic grey haze.
- **Level 3 (Inspection Overlays & Modals)**: Background `#FAF8F5`, supported by `0 16px 36px -8px rgba(25, 24, 22, 0.12)`. Modal backdrops use `#191816` at 35% opacity with an 8px blur to keep attention focused on verification details.

## Shapes

The design system uses soft, welcoming curvature that mirrors tailored cloth, rounded pocket seams, and garment hangtags.

- **Primary Cards & Containers**: `1rem` to `1.25rem` (`rounded-xl` to `rounded-2xl`).
- **Interactive Badges, Search Bars, and Filter Chips**: Pill shapes (`rounded-full` / `9999px`) to create an inviting, low-friction tap target.
- **Thumbnails & Media Assets**: Standardized `0.75rem` (12px) to softly frame raw textile edges without cutting into corner information.

## Components

### Buttons
- **Primary Action**: Solid `#191816` background, `#FAF8F5` text, pill-shaped (`rounded-full`), min-height 48px on mobile for ergonomic reach. Subtle press-in scale (`scale-98`) on tap.
- **Secondary Action**: Background `#F5F2EC`, border 1px solid `#E7E3DB`, text `#191816`, pill-shaped. Hover shifts to `#ECE7DF`.
- **Text / Quiet Action**: No background, text `#191816` with bottom underline rendered in `#876ED4` or `#E7E3DB`.

### Pill Filters & Chips
- Resting: Height 36px, background `#FAF8F5`, 1px solid `#E7E3DB`, text `#2D2B28`, font `label-md`.
- Active / Selected: Background `#191816`, border 1px solid `#191816`, text `#FAF8F5`.
- Attribute Filter (Condition / Fiber / Match): Background tinted to the respective accent (e.g., `#DCF2E7` for Mint condition), with a 4px leading colored dot.

### Garment Cards
- Base: Surface `#F5F2EC`, border 1px solid `#E7E3DB`, `rounded-2xl`, overflow hidden.
- Media Container: Aspect ratio 4:5, crisp un-retouched garment imagery with off-white studio backdrops.
- Metadata block: Padded with `space-md`. Displays brand in `label-sm`, title in `headline-sm`, and price in `headline-sm`.
- Evidence Badge: Pinned to upper right or bottom row, showing Match score or Wear indicator pill.

### Match & Measurement Gauge
- A dedicated component comparing buyer body/garment measurements against the item's flat measurements.
- Horizontal dual-bar visualization: Muted baseline track in `#ECE7DF`, match indicator in `#876ED4` (Lilac).
- Difference flagged with textual honesty (e.g., "+0.5 in chest: relaxed drape").

### Flaw & Wear Indicators
- Never masked under generic ratings. Displayed via `#FCE5EC` pill containers with `#B85978` typography.
- Tap reveals macro high-resolution detail photograph with an explanatory micro-caption.

### Inputs & Search
- Background `#FAF8F5`, 1px solid `#E7E3DB`, height 48px, `rounded-xl` or `rounded-full` for search.
- Focus state: Border color transitions to `#191816` with zero synthetic outer halo ring.
- Placeholder text in `#6E6A63`.